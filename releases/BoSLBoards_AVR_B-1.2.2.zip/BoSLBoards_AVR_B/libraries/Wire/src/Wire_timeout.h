// Enable Wire timeout by uncommenting the line below
// Wire timeout is currently only implemented on devices with hardware TWI,
// which means that there's no timeout support for ATmegaXX5/XX50 and ATmegaXX9/XX90
#ifndef WIRE_TIMEOUT
//#define WIRE_TIMEOUT
#endif